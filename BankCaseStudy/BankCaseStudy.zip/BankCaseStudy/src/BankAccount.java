// Base Class
import java.time.LocalDate;

abstract class BankAccount {
    private String accountNumber;
    private String accountHolderName;
    protected double balance;
    LocalDate lastTransactionDate;

    // Constructor
    
    public BankAccount() {
        this.accountNumber = "not define";
        this.accountHolderName = "not define";
        this.balance = 0;
    }
    
    public BankAccount(String accountNumber, String accountHolderName, double balance) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.balance = balance;
        this.lastTransactionDate = LocalDate.now();
    }

    // Getters and Setters
    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    // Common Methods
    public void deposit(double amount) {
        balance = balance + amount;
        System.out.println("Deposited: ₹" + amount + " | New Balance: ₹" + balance);
    }

    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawn: ₹" + amount + " | Remaining Balance: ₹" + balance);
        } else {
            System.out.println(" Insufficient balance!");
        }
    }

    public void displayDetails() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Holder Name: " + accountHolderName);
        System.out.println("Balance: ₹" + balance);
    }
}

// Saving Account
class SavingAccount extends BankAccount {
    private double minBalance = 2000;

    
    public SavingAccount() {
        super();
        this.minBalance = 0;
    }
    
    public SavingAccount(String accNo, String name, double bal) {
        super(accNo, name, bal);
       
    }

    // Getter & Setter
    public double getMinBalance() {
        return minBalance;
    }

    public void setMinBalance(double minBalance) {
        this.minBalance = minBalance;
    }

    @Override
    public void withdraw(double amount) {
        if (balance - amount >= minBalance) {
            balance -= amount;
            System.out.println("Withdrawn: ₹" + amount + " | Remaining Balance: ₹" + balance);
        } else {
            System.out.println("❌ Cannot withdraw! Minimum balance should be ₹" + minBalance);
        }
    }
}

// Current Account
class CurrentAccount extends BankAccount {
    private double overdraftLimit = 5000;
    private int transactionLimit = 10;
    private int transactions = 0;

    
    public CurrentAccount() {
        super();
    }
    
    public CurrentAccount(String accNo, String name, double bal) {
        super(accNo, name, bal);
    }

    // Getters & Setters
    public double getOverdraftLimit() {
        return overdraftLimit;
    }

    public void setOverdraftLimit(double overdraftLimit) {
        this.overdraftLimit = overdraftLimit;
    }

    public int getTransactionLimit() {
        return transactionLimit;
    }

    public void setTransactionLimit(int transactionLimit) {
        this.transactionLimit = transactionLimit;
    }

    public int getTransactions() {
        return transactions;
    }

    public void setTransactions(int transactions) {
        this.transactions = transactions;
    }

    @Override
    public void withdraw(double amount) {
        if (transactions >= transactionLimit) {
            System.out.println("❌ Transaction limit reached (" + transactionLimit + ")");
            return;
        }

        if (balance + overdraftLimit >= amount) {
            balance -= amount;
            transactions++;
            System.out.println("Withdrawn: ₹" + amount + " | Remaining Balance: ₹" + balance +
                    " | Transactions: " + transactions);
        } else {
            System.out.println("❌ Overdraft limit exceeded!");
        }
    }
}

// Salary Account
class SalaryAccount extends BankAccount {
	private String salaryDate;
	private String lastTransactionDate;

     
     public SalaryAccount() {
         super();
         this.salaryDate = "not define";
         this.lastTransactionDate = "not define";
     }
     
    public SalaryAccount(String accNo, String name, double bal, String salaryDate, String lastTransactionDate) {
        super(accNo, name, bal);
        this.salaryDate = salaryDate;
        this.lastTransactionDate = lastTransactionDate;
    }

    // Getters & Setters
    public String getSalaryDate() {
        return salaryDate;
    }

    public void setSalaryDate(String salaryDate) {
        this.salaryDate = salaryDate;
    }

    public String getLastTransactionDate() {
        return lastTransactionDate;
    }

    public void setLastTransactionDate(String lastTransactionDate) {
        this.lastTransactionDate = lastTransactionDate;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Salary Date: " + salaryDate);
        System.out.println("Last Transaction Date: " + lastTransactionDate);
    }
}

// Loan Account
class LoanAccount extends BankAccount {
   private double loanAmount;
   private double rateOfInterest;

    
    public LoanAccount() {
        super();
        this.loanAmount = 0;
        this.rateOfInterest = 0;
    }
    
    public LoanAccount(String accNo, String name, double loanAmount, double rateOfInterest) {
        super(accNo, name, 0);
        this.loanAmount = loanAmount;
        this.rateOfInterest = rateOfInterest;
    }

    // Getters & Setters
    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public double getRateOfInterest() {
        return rateOfInterest;
    }

    public void setRateOfInterest(double rateOfInterest) {
        this.rateOfInterest = rateOfInterest;
    }

    // Custom Method
    public void calculateInterest() {
        double interest = loanAmount * rateOfInterest / 100;
        System.out.println("Interest on loan: ₹" + interest);
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Loan Amount: ₹" + loanAmount);
        System.out.println("Interest Rate: " + rateOfInterest + "%");
    }
}

// Main Class to Test
 class Main {
    public static void main(String[] args) {
        // Saving Account Test

SavingAccount sa = new SavingAccount("SA101", "Rutika", 5000);
        sa.withdraw(3500);
        sa.deposit(2000);

        System.out.println("\n--- Current Account ---");
        CurrentAccount ca = new CurrentAccount("CA102", "Amit", 1000);
        ca.withdraw(5500);
        ca.withdraw(1000);

        System.out.println("\n--- Salary Account ---");
        SalaryAccount salAcc = new SalaryAccount("SAL103", "Priya", 15000, "10th Oct", "8th Oct");
        salAcc.displayDetails();

        System.out.println("\n--- Loan Account ---");
        LoanAccount la = new LoanAccount("LN104", "Raj", 200000, 8.5);
        la.displayDetails();
        la.calculateInterest();
    }
}
