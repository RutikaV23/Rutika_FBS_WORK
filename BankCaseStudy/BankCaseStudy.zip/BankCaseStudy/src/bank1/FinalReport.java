// FinalReport
package bank1;
import java.util.ArrayList;

import transcationRecords.Transaction;
import accounts.BankAccount;
import accounts.SalaryAccount;

class FinalReport {
        public static void generate(ArrayList<BankAccount> accounts) {
            double totalBalance = 0;
            int frozenCount = 0;

            for (BankAccount acc : accounts) {
                totalBalance += acc.getBalance();
                if (acc instanceof SalaryAccount sa) {
                    sa.checkForFreeze();
                    if (sa.isFrozen()) frozenCount++;
                }
            }

            System.out.println("\n📊 End-of-Day Bank Report");
            System.out.println("================================");
            System.out.println("Total Accounts: " + accounts.size());
            System.out.println("Total Balance: ₹" + totalBalance);
            System.out.println("Total Deposited: ₹" + Transaction.totalDeposits());
            System.out.println("Total Withdrawn: ₹" + Transaction.totalWithdrawals());
            System.out.println("Frozen Salary Accounts: " + frozenCount);
            System.out.println("================================\n");
        }
 }

