import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

class Transaction {
	
	private static ArrayList<Transaction> transactions = new ArrayList<>();
    private static int idCounter = 1; // auto-increment transaction ID

    private int transactionId;
    private String accountNo, type, date;
    private double amount;


    // Default constructor
    public Transaction() {
        this.transactionId = 0;
        this.accountNo = "Not defined";
        this.type = "Not defined";
        this.amount = 0;
        this.date = "Not defined";
    }
    
 // Parameterized constructor (no need for date parameter)
    public Transaction(String accountNo, String type, double amount) {
        this.transactionId = idCounter++;
        this.accountNo = accountNo;
        this.type = type;
        this.amount = amount;
        this.date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    // Getters & Setters
    public int getTransactionId() 
    {
    	return transactionId; 
    }
    
    public void setTransactionId(int transactionId) 
    {
    	this.transactionId = transactionId; 
    }

    public String getAccountNo() 
    {
    	return accountNo; 
    }
    public void setAccountNo(String accountNo) 
    {
    	this.accountNo = accountNo; 
    }
    
    public String getType() 
    {
    	return type; 
    }
    public void setType(String type) 
    {
    	this.type = type; 
    }

    public double getAmount() 
    {
    	return amount; 
    }
    public void setAmount(double amount) 
    {
    	this.amount = amount; 
    }

    public String getDate() 
    {
    	return date; 
    }
    public void setDate(String date) 
    {
    	this.date = date; 
    }

    // Static Method
    public static void record(String accountNo, String type, double amount) {
        transactions.add(new Transaction(accountNo, type, amount));
    }
    
 // Display all transactions
    public static void showAll() {
        System.out.println("\n📜 Transaction History:");
        if (transactions.isEmpty()) {
            System.out.println("No transactions recorded yet.");
        } else {
            for (Transaction t : transactions) {
                System.out.println("ID: " + t.transactionId + " | " + t.date + " | " +
                                   "Account: " + t.accountNo + " | Type: " + t.type + " | ₹" + t.amount);
            }
        }
    }
    
    public static double totalDeposits() {
        double total = 0;
        for (Transaction t : transactions) {
            // if transaction type contains the word "Deposit"
            if (t.type.contains("Deposit")) {
                total += t.amount;
            }
        }
        return total;
    }

    public static double totalWithdrawals() {
        double total = 0;
        for (Transaction t : transactions) {
            // if transaction type is exactly "Withdraw"
            if (t.type.equals("Withdraw")) {
                total += t.amount;
            }
        }
        return total;
    }

}

public static void TestTranscation() 
{
	Transaction.record("AC101", "Deposit", 5000);
	Transaction.record("AC101", "Withdraw", 2000);
	Transaction.showAll();

}
