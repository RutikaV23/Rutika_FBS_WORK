package Main;

import bank1.Bank;

public class Test
{
	    public static void main(String[] args) {
	        Bank bank = new Bank("XYZ Bank");
	        bank.menu();
	    }
}

