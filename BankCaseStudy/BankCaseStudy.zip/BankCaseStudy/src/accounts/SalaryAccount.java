package accounts;

import java.time.LocalDate;
import java.time.Period;
//Salary Account
public class SalaryAccount extends BankAccount {
	private LocalDate salaryDate;
	private LocalDate lastTransactionDate;
	private boolean isFrozen = false;

  
  public SalaryAccount() {
      super();
      this.salaryDate = LocalDate.now();
      this.lastTransactionDate = LocalDate.now();
  }
  
  public SalaryAccount(String accNo, String name, double bal, LocalDate lastTransactionDate) {
      super(accNo, name, bal);
      this.salaryDate = LocalDate.now();
      this.lastTransactionDate = lastTransactionDate;
  }

 // Getters & Setters

 public LocalDate getLastTransactionDate() {
     return lastTransactionDate;
 }

 public void setLastTransactionDate(LocalDate lastTransactionDate) {
     this.lastTransactionDate = lastTransactionDate;
 }
 
 public boolean isFrozen() 
 {
	 return isFrozen; 
 }

 public void checkForFreeze() {
     LocalDate today = LocalDate.now();
     Period diff = Period.between(lastTransactionDate, today);
     if (diff.getMonths() >= 2)
         isFrozen = true;
 }
 

 @Override
 public void displayDetails() {
     super.displayDetails();
     System.out.println("Salary Date: " + salaryDate);
     System.out.println("Last Transaction Date: " + lastTransactionDate);
 }
}

